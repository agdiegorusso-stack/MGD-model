from pathlib import Path
import sys
root=Path(sys.argv[1])

# -----------------------------------------------------------------------------
# 0.26 storage: binary MGD snapshots + SQLite/WAL language graph.
# -----------------------------------------------------------------------------
codec = r'''import 'dart:convert';
import 'dart:typed_data';

/// Compact deterministic binary codec used by MGD snapshots.
///
/// It deliberately avoids JSON on disk. Supported values are exactly the
/// primitive tree produced by the existing toJson() methods: null, bool, int,
/// double, String, List and Map<String,dynamic>.
class MgdBinaryCodec26 {
  static const List<int> _magic = <int>[0x4d, 0x47, 0x44, 0x32, 0x36, 0x01];

  static Uint8List encode(Map<String, dynamic> map) {
    final w = _MgdWriter26();
    w.bytes.add(_magic);
    w.value(map);
    return w.take();
  }

  static Map<String, dynamic> decode(Uint8List bytes) {
    if (bytes.length < _magic.length) {
      throw const FormatException('Snapshot MGD troppo corto');
    }
    for (var i = 0; i < _magic.length; i++) {
      if (bytes[i] != _magic[i]) {
        throw const FormatException('Snapshot MGD non riconosciuto');
      }
    }
    final r = _MgdReader26(bytes, _magic.length);
    final out = r.value();
    if (out is! Map) throw const FormatException('Root MGD non è una mappa');
    return Map<String, dynamic>.from(out);
  }
}

class _MgdWriter26 {
  final BytesBuilder bytes = BytesBuilder(copy: false);

  Uint8List take() => bytes.takeBytes();

  void _u32(int v) {
    final b = ByteData(4)..setUint32(0, v, Endian.little);
    bytes.add(b.buffer.asUint8List());
  }

  void _i64(int v) {
    final b = ByteData(8)..setInt64(0, v, Endian.little);
    bytes.add(b.buffer.asUint8List());
  }

  void _f64(double v) {
    final b = ByteData(8)..setFloat64(0, v, Endian.little);
    bytes.add(b.buffer.asUint8List());
  }

  void _stringRaw(String s) {
    final x = utf8.encode(s);
    _u32(x.length);
    bytes.add(x);
  }

  void value(dynamic v) {
    if (v == null) {
      bytes.addByte(0);
    } else if (v is bool) {
      bytes.addByte(v ? 2 : 1);
    } else if (v is int) {
      bytes.addByte(3);
      _i64(v);
    } else if (v is double) {
      bytes.addByte(4);
      _f64(v);
    } else if (v is num) {
      bytes.addByte(4);
      _f64(v.toDouble());
    } else if (v is String) {
      bytes.addByte(5);
      _stringRaw(v);
    } else if (v is List) {
      bytes.addByte(6);
      _u32(v.length);
      for (final x in v) value(x);
    } else if (v is Map) {
      bytes.addByte(7);
      _u32(v.length);
      for (final e in v.entries) {
        _stringRaw(e.key.toString());
        value(e.value);
      }
    } else {
      throw FormatException('Tipo non supportato nello snapshot MGD: ${v.runtimeType}');
    }
  }
}

class _MgdReader26 {
  final Uint8List data;
  int offset;
  _MgdReader26(this.data, this.offset);

  void _need(int n) {
    if (offset + n > data.length) throw const FormatException('Snapshot MGD troncato');
  }

  int _u32() {
    _need(4);
    final v = ByteData.sublistView(data, offset, offset + 4).getUint32(0, Endian.little);
    offset += 4;
    return v;
  }

  int _i64() {
    _need(8);
    final v = ByteData.sublistView(data, offset, offset + 8).getInt64(0, Endian.little);
    offset += 8;
    return v;
  }

  double _f64() {
    _need(8);
    final v = ByteData.sublistView(data, offset, offset + 8).getFloat64(0, Endian.little);
    offset += 8;
    return v;
  }

  String _stringRaw() {
    final n = _u32();
    _need(n);
    final s = utf8.decode(data.sublist(offset, offset + n));
    offset += n;
    return s;
  }

  dynamic value() {
    _need(1);
    final tag = data[offset++];
    switch (tag) {
      case 0: return null;
      case 1: return false;
      case 2: return true;
      case 3: return _i64();
      case 4: return _f64();
      case 5: return _stringRaw();
      case 6:
        final n = _u32();
        return List<dynamic>.generate(n, (_) => value(), growable: false);
      case 7:
        final n = _u32();
        final m = <String, dynamic>{};
        for (var i = 0; i < n; i++) m[_stringRaw()] = value();
        return m;
      default:
        throw FormatException('Tag MGD sconosciuto: $tag');
    }
  }
}
'''
(root/'lib'/'mgd_binary_codec_v026.dart').write_text(codec)

# Brain persistence: binary snapshots, JSON.gz only as backward-compatible migration source.
brain_persist = r'''import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';

import 'mgd_binary_codec_v026.dart';
import 'plastic_language_brain_v04.dart';

List<int> _encodeJsonMapGzip19(Map<String, dynamic> map) =>
    gzip.encode(utf8.encode(jsonEncode(map)));
Map<String, dynamic> _decodeJsonMapGzip19(List<int> bytes) => Map<String, dynamic>.from(
      jsonDecode(utf8.decode(gzip.decode(bytes))) as Map,
    );
Uint8List _encodeBrainBinary26(Map<String, dynamic> map) => MgdBinaryCodec26.encode(map);
Map<String, dynamic> _decodeBrainBinary26(Uint8List bytes) => MgdBinaryCodec26.decode(bytes);

class Brain04Persistence {
  static const _binaryName = 'mgd_neuro_brain_v026.mgb';
  static const _fileName = 'mgd_neuro_brain_v051.json.gz';
  static const _oldV05FileName = 'mgd_neuro_brain_v05.json.gz';
  static const _oldV04FileName = 'mgd_neuro_brain_v04.json.gz';
  static const _oldV03FileName = 'mgd_neuro_brain_v03.json.gz';

  Future<void>? _activeSave19;
  bool _saveQueued19 = false;
  PlasticLanguageBrain04? _saveBrain19;

  Future<File> _file(String name) async {
    final dir = await getApplicationDocumentsDirectory();
    return File('${dir.path}/$name');
  }

  Future<void> save(PlasticLanguageBrain04 brain) {
    _saveBrain19 = brain;
    _saveQueued19 = true;
    return _activeSave19 ??= _drainSaves19().whenComplete(() {
      _activeSave19 = null;
      if (_saveQueued19 && _saveBrain19 != null) save(_saveBrain19!);
    });
  }

  Future<void> _drainSaves19() async {
    while (_saveQueued19 && _saveBrain19 != null) {
      _saveQueued19 = false;
      final snapshot = _saveBrain19!.toJson();
      final bytes = await compute(_encodeBrainBinary26, snapshot);
      await _atomicReplace19(await _file(_binaryName), bytes);
    }
  }

  Future<void> _atomicReplace19(File file, List<int> bytes) async {
    final tmp = File('${file.path}.tmp');
    final bak = File('${file.path}.bak');
    try {
      if (await tmp.exists()) await tmp.delete();
      await tmp.writeAsBytes(bytes, flush: true);
      if (await file.exists()) {
        try { if (await bak.exists()) await bak.delete(); await file.copy(bak.path); } catch (_) {}
        await file.delete();
      }
      await tmp.rename(file.path);
    } finally {
      if (await tmp.exists()) { try { await tmp.delete(); } catch (_) {} }
    }
  }

  Future<PlasticLanguageBrain04?> _loadBinary(File f) async {
    if (!await f.exists()) return null;
    final map = await compute(_decodeBrainBinary26, await f.readAsBytes());
    return PlasticLanguageBrain04.fromJson(map);
  }

  Future<PlasticLanguageBrain04?> _loadLegacy(File file) async {
    if (!await file.exists()) return null;
    final map = await compute(_decodeJsonMapGzip19, await file.readAsBytes());
    return PlasticLanguageBrain04.fromJson(map);
  }

  Future<({PlasticLanguageBrain04 brain, bool migrated})?> load() async {
    final binary = await _file(_binaryName);
    try {
      final brain = await _loadBinary(binary);
      if (brain != null) return (brain: brain, migrated: false);
    } catch (_) {}
    try {
      final brain = await _loadBinary(File('${binary.path}.bak'));
      if (brain != null) return (brain: brain, migrated: false);
    } catch (_) {}

    // One-time migration from old JSON.gz. Do not keep JSON as the active store.
    for (final legacyName in [_fileName, _oldV05FileName, _oldV04FileName]) {
      try {
        final brain = await _loadLegacy(await _file(legacyName));
        if (brain != null) {
          unawaited(Future<void>.delayed(const Duration(milliseconds: 700), () => save(brain)));
          return (brain: brain, migrated: legacyName != _fileName);
        }
      } catch (_) {}
    }
    try {
      final old = await _file(_oldV03FileName);
      if (await old.exists()) {
        final map = await compute(_decodeJsonMapGzip19, await old.readAsBytes());
        final brain = PlasticLanguageBrain04.migrateFromV03(map);
        unawaited(Future<void>.delayed(const Duration(milliseconds: 700), () => save(brain)));
        return (brain: brain, migrated: true);
      }
    } catch (_) {}
    return null;
  }

  Future<void> clear() async {
    for (final name in [_binaryName, _fileName, _oldV05FileName, _oldV04FileName, _oldV03FileName]) {
      final file = await _file(name);
      for (final f in [file, File('${file.path}.bak'), File('${file.path}.tmp')]) {
        if (await f.exists()) await f.delete();
      }
    }
  }
}
'''
(root/'lib'/'persistence.dart').write_text(brain_persist)

world_persist = r'''import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';

import 'mgd_binary_codec_v026.dart';
import 'sensory_world_v06.dart';

Map<String, dynamic> _decodeWorldLegacy26(List<int> bytes) => Map<String, dynamic>.from(
  jsonDecode(utf8.decode(gzip.decode(bytes))) as Map,
);
Uint8List _encodeWorldBinary26(Map<String,dynamic> map)=>MgdBinaryCodec26.encode(map);
Map<String,dynamic> _decodeWorldBinary26(Uint8List bytes)=>MgdBinaryCodec26.decode(bytes);

class WorldPersistence06 {
  static const _binaryName='mgd_neuro_world_v026.mgb';
  static const _legacyName='mgd_neuro_world_v06.json.gz';
  Future<void>? _activeSave19;
  bool _saveQueued19=false;
  MgdWorld06? _saveWorld19;

  Future<Directory> _dir()=>getApplicationDocumentsDirectory();
  Future<File> _file(String name) async=>File('${(await _dir()).path}/$name');

  Future<MgdWorld06?> _loadBinary(File f) async {
    if(!await f.exists())return null;
    final map=await compute(_decodeWorldBinary26,await f.readAsBytes());
    return MgdWorld06.fromJson(map);
  }
  Future<MgdWorld06?> _loadLegacy(File f) async {
    if(!await f.exists())return null;
    final map=await compute(_decodeWorldLegacy26,await f.readAsBytes());
    return MgdWorld06.fromJson(map);
  }

  Future<MgdWorld06?> load() async {
    final b=await _file(_binaryName);
    try{final x=await _loadBinary(b);if(x!=null)return x;}catch(_){}
    try{final x=await _loadBinary(File('${b.path}.bak'));if(x!=null)return x;}catch(_){}
    final legacy=await _file(_legacyName);
    try{
      final x=await _loadLegacy(legacy);
      if(x!=null){unawaited(Future<void>.delayed(const Duration(milliseconds:900),()=>save(x)));return x;}
    }catch(_){}
    try{return await _loadLegacy(File('${legacy.path}.bak'));}catch(_){return null;}
  }

  Future<void> save(MgdWorld06 world){
    _saveWorld19=world;_saveQueued19=true;
    return _activeSave19??=_drain19().whenComplete((){
      _activeSave19=null;if(_saveQueued19&&_saveWorld19!=null)save(_saveWorld19!);
    });
  }
  Future<void> _drain19() async {
    while(_saveQueued19&&_saveWorld19!=null){
      _saveQueued19=false;
      final bytes=await compute(_encodeWorldBinary26,_saveWorld19!.toJson());
      final f=await _file(_binaryName),tmp=File('${f.path}.tmp'),bak=File('${f.path}.bak');
      try{
        if(await tmp.exists())await tmp.delete();
        await tmp.writeAsBytes(bytes,flush:true);
        if(await f.exists()){try{if(await bak.exists())await bak.delete();await f.copy(bak.path);}catch(_){}await f.delete();}
        await tmp.rename(f.path);
      }finally{if(await tmp.exists()){try{await tmp.delete();}catch(_){}}}
    }
  }
  Future<void> clear() async {
    for(final name in [_binaryName,_legacyName]){
      final f=await _file(name);
      for(final x in [f,File('${f.path}.bak'),File('${f.path}.tmp')])if(await x.exists())await x.delete();
    }
  }
}
'''
(root/'lib'/'world_persistence_v06.dart').write_text(world_persist)

research_persist = r'''import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';

import 'mgd_binary_codec_v026.dart';
import 'web_knowledge_explorer_v11.dart';

Map<String,dynamic> _decodeResearchLegacy26(List<int> bytes)=>Map<String,dynamic>.from(
  jsonDecode(utf8.decode(gzip.decode(bytes))) as Map,
);
Uint8List _encodeResearchBinary26(Map<String,dynamic> map)=>MgdBinaryCodec26.encode(map);
Map<String,dynamic> _decodeResearchBinary26(Uint8List bytes)=>MgdBinaryCodec26.decode(bytes);

class ResearchPersistence11 {
  static const _binaryName='mgd_neuro_research_v026.mgb';
  static const _legacyName='mgd_neuro_research_v11.json.gz';
  static const _olderName='mgd_neuro_research_v10.json.gz';
  Future<void>? _activeSave19;
  bool _saveQueued19=false;
  ResearchMemory11? _saveMemory19;

  Future<Directory> _dir()=>getApplicationDocumentsDirectory();
  Future<File> _file(String name) async=>File('${(await _dir()).path}/$name');
  Future<ResearchMemory11?> _loadBinary(File f) async {
    if(!await f.exists())return null;
    final map=await compute(_decodeResearchBinary26,await f.readAsBytes());
    return ResearchMemory11.fromJson(map);
  }
  Future<ResearchMemory11?> _loadLegacy(File f) async {
    if(!await f.exists())return null;
    final map=await compute(_decodeResearchLegacy26,await f.readAsBytes());
    return ResearchMemory11.fromJson(map);
  }

  Future<ResearchMemory11?> load() async {
    final b=await _file(_binaryName);
    try{final x=await _loadBinary(b);if(x!=null)return x;}catch(_){}
    try{final x=await _loadBinary(File('${b.path}.bak'));if(x!=null)return x;}catch(_){}
    final legacy=await _file(_legacyName);
    try{
      final x=await _loadLegacy(legacy);
      if(x!=null){unawaited(Future<void>.delayed(const Duration(milliseconds:1100),()=>save(x)));return x;}
    }catch(_){}
    // Old v10 only carried lightweight research configuration.
    try{
      final f=await _file(_olderName);
      if(!await f.exists())return null;
      final map=await compute(_decodeResearchLegacy26,await f.readAsBytes());
      return ResearchMemory11(
        enabled:map['enabled']!=false,
        dailyBudget:(map['dailyBudget'] as num?)?.toInt()??0,
        requestsToday:(map['requestsToday'] as num?)?.toInt()??0,
        dayKey:(map['dayKey']??'').toString(),
        lastResearchAtIso:map['lastResearchAtIso'] as String?,
        lastGoal:map['lastGoal'] as String?,
        lastStatus:'Motore ricerca migrato allo store binario MGD 0.26.',
      );
    }catch(_){return null;}
  }

  Future<void> save(ResearchMemory11 memory){
    _saveMemory19=memory;_saveQueued19=true;
    return _activeSave19??=_drain19().whenComplete((){
      _activeSave19=null;if(_saveQueued19&&_saveMemory19!=null)save(_saveMemory19!);
    });
  }
  Future<void> _drain19() async {
    while(_saveQueued19&&_saveMemory19!=null){
      _saveQueued19=false;
      final memory=_saveMemory19!;memory.trim();
      final bytes=await compute(_encodeResearchBinary26,memory.toJson());
      final f=await _file(_binaryName),tmp=File('${f.path}.tmp'),bak=File('${f.path}.bak');
      try{
        if(await tmp.exists())await tmp.delete();
        await tmp.writeAsBytes(bytes,flush:true);
        if(await f.exists()){try{if(await bak.exists())await bak.delete();await f.copy(bak.path);}catch(_){}await f.delete();}
        await tmp.rename(f.path);
      }finally{if(await tmp.exists()){try{await tmp.delete();}catch(_){}}}
    }
  }
  Future<void> clear() async {
    for(final name in [_binaryName,_legacyName,_olderName]){
      final f=await _file(name);
      for(final x in [f,File('${f.path}.bak'),File('${f.path}.tmp')])if(await x.exists())await x.delete();
    }
  }
}
'''
(root/'lib'/'research_persistence_v11.dart').write_text(research_persist)

# -----------------------------------------------------------------------------
# Language graph -> SQLite/WAL with delta updates; legacy JSON only migrates once.
# -----------------------------------------------------------------------------
p=root/'lib'/'mgd_language_v020.dart'
s=p.read_text()
if "package:sqflite/sqflite.dart" not in s:
    s=s.replace("import 'package:path_provider/path_provider.dart';", "import 'package:path_provider/path_provider.dart';\nimport 'package:sqflite/sqflite.dart';",1)
# Dirty sets.
anchor="""  bool _indexesReady21=false;
  int lastGenerateMicros21=0;"""
replacement="""  bool _indexesReady21=false;

  // 0.26: incremental persistence. Only structures changed since the previous
  // checkpoint are written to SQLite/WAL; the whole language graph is no longer
  // serialized into one JSON document after every interaction.
  final Set<String> _dirtyTokens26=<String>{};
  final Set<String> _dirtyEdges26=<String>{};
  final Set<String> _dirtyChunks26=<String>{};
  final Set<String> _deletedChunks26=<String>{};
  bool _metaDirty26=false;

  int lastGenerateMicros21=0;"""
if anchor not in s: raise SystemExit('language dirty anchor missing')
s=s.replace(anchor,replacement,1)
# Mark characters/meta.
s=s.replace("final raw=text.trim(); if(raw.isEmpty)return; characters+=raw.length;", "final raw=text.trim(); if(raw.isEmpty)return; characters+=raw.length; _metaDirty26=true;",1)
s=s.replace("final xs=toks(sentence); if(xs.isEmpty)continue; sentences++;", "final xs=toks(sentence); if(xs.isEmpty)continue; sentences++; _metaDirty26=true;",1)
s=s.replace("for(final x in xs){tokenCount[x]=(tokenCount[x]??0)+1;}", "for(final x in xs){tokenCount[x]=(tokenCount[x]??0)+1;_dirtyTokens26.add(x);}",1)
# Edge dirty after update; insert before flux.
s=s.replace("e.cost=(1.12-.62*e.slow-.38*min(e.material,mStar)+.95*saturation+.08*(1-reward)).clamp(.08,2.4);\n        flux+=", "e.cost=(1.12-.62*e.slow-.38*min(e.material,mStar)+.95*saturation+.08*(1-reward)).clamp(.08,2.4);\n        _dirtyEdges26.add(k);\n        flux+=",1)
# Chunk dirty.
s=s.replace("c.count++; final target=(c.count/(c.count+4.0)).clamp(0.0,1.0); c.material=(.93*c.material+.07*target+xi*c.material*(1-c.material)).clamp(0.0,1.0);\n          _indexChunk21(c);", "c.count++; final target=(c.count/(c.count+4.0)).clamp(0.0,1.0); c.material=(.93*c.material+.07*target+xi*c.material*(1-c.material)).clamp(0.0,1.0);\n          _dirtyChunks26.add(phrase); _deletedChunks26.remove(phrase);\n          _indexChunk21(c);",1)
# Replace chunk pruning with delete tracking.
old="""    final beforeChunks=chunks.length;
    chunks.removeWhere((_,c)=>c.count<3 && chunks.length>5000);
    if(chunks.length!=beforeChunks)_rebuildIndexes21();
    lastFlux=flux;"""
new="""    final beforeChunks=chunks.length;
    if(chunks.length>5000){
      final remove=chunks.entries.where((e)=>e.value.count<3).map((e)=>e.key).toList();
      for(final k in remove){chunks.remove(k);_dirtyChunks26.remove(k);_deletedChunks26.add(k);}
    }
    if(chunks.length!=beforeChunks)_rebuildIndexes21();
    lastFlux=flux; _metaDirty26=true;"""
if old not in s: raise SystemExit('chunk prune anchor missing')
s=s.replace(old,new,1)
# Add delta helpers before toJson.
anchor="""  Map<String,dynamic> toJson()=>{'v':1,'tc':tokenCount,'e':edges.values.map((x)=>x.toJson()).toList(),'ch':chunks.values.map((x)=>x.toJson()).toList(),'sentences':sentences,'characters':characters,'flux':lastFlux};"""
helper=r'''  Map<String,dynamic> _takeDelta26(){
    final out=<String,dynamic>{
      'tokens':<Map<String,dynamic>>[for(final k in _dirtyTokens26)if(tokenCount.containsKey(k)){'t':k,'c':tokenCount[k]}],
      'edges':<Map<String,dynamic>>[for(final k in _dirtyEdges26)if(edges.containsKey(k)){'k':k,...edges[k]!.toJson()}],
      'chunks':<Map<String,dynamic>>[for(final k in _dirtyChunks26)if(chunks.containsKey(k)){'h':k.split(' ').first,...chunks[k]!.toJson()}],
      'deletedChunks':_deletedChunks26.toList(),
      'meta':_metaDirty26?{'sentences':sentences,'characters':characters,'flux':lastFlux}:null,
    };
    _dirtyTokens26.clear();_dirtyEdges26.clear();_dirtyChunks26.clear();_deletedChunks26.clear();_metaDirty26=false;
    return out;
  }
  void _restoreDelta26(Map<String,dynamic> d){
    for(final x in (d['tokens'] as List? ?? const[])){if(x is Map)_dirtyTokens26.add((x['t']??'').toString());}
    for(final x in (d['edges'] as List? ?? const[])){if(x is Map)_dirtyEdges26.add((x['k']??'').toString());}
    for(final x in (d['chunks'] as List? ?? const[])){if(x is Map)_dirtyChunks26.add((x['t']??'').toString());}
    for(final x in (d['deletedChunks'] as List? ?? const[]))_deletedChunks26.add(x.toString());
    if(d['meta']!=null)_metaDirty26=true;
  }
  bool get _hasDirty26=>_dirtyTokens26.isNotEmpty||_dirtyEdges26.isNotEmpty||_dirtyChunks26.isNotEmpty||_deletedChunks26.isNotEmpty||_metaDirty26;

'''+anchor
if anchor not in s: raise SystemExit('toJson helper anchor missing')
s=s.replace(anchor,helper,1)
# Replace persistence class entirely.
start=s.index('class MgdLanguagePersistence20 {')
end=s.index('\nclass MgdLanguageLab20',start)
new_persist=r'''class MgdLanguagePersistence20 {
  Database? _db26;
  Future<void>? _migration26;
  Future<void> _saveTail = Future<void>.value();

  Future<String> _dbPath26() async => '${await getDatabasesPath()}/mgd_language26.db';
  Future<File> _legacyFile26() async=>File('${(await getApplicationDocumentsDirectory()).path}/mgd_language20.json');

  Future<Database> _db() async {
    if(_db26!=null)return _db26!;
    final db=await openDatabase(
      await _dbPath26(),
      version:1,
      onConfigure:(db) async {
        await db.rawQuery('PRAGMA journal_mode=WAL');
        await db.rawQuery('PRAGMA synchronous=NORMAL');
        await db.rawQuery('PRAGMA temp_store=MEMORY');
      },
      onCreate:(db,_) async {
        await db.execute('CREATE TABLE meta(k TEXT PRIMARY KEY,v TEXT NOT NULL)');
        await db.execute('CREATE TABLE token(t TEXT PRIMARY KEY,c INTEGER NOT NULL)');
        await db.execute('CREATE TABLE edge(k TEXT PRIMARY KEY,a TEXT NOT NULL,b TEXT NOT NULL,u INTEGER NOT NULL,f REAL NOT NULL,s REAL NOT NULL,m REAL NOT NULL,cost REAL NOT NULL)');
        await db.execute('CREATE INDEX edge_from_idx ON edge(a)');
        await db.execute('CREATE TABLE chunk(t TEXT PRIMARY KEY,h TEXT NOT NULL,c INTEGER NOT NULL,m REAL NOT NULL)');
        await db.execute('CREATE INDEX chunk_head_idx ON chunk(h)');
      },
    );
    _db26=db;return db;
  }

  Future<MgdLanguage20?> _loadDb26(Database db) async {
    final init=await db.query('meta',where:'k=?',whereArgs:['initialized'],limit:1);
    if(init.isEmpty)return null;
    final m=MgdLanguage20();
    for(final r in await db.query('token'))m.tokenCount[(r['t']??'').toString()]=(r['c'] as num?)?.toInt()??0;
    for(final r in await db.query('edge')){
      final e=_LangEdge20((r['a']??'').toString(),(r['b']??'').toString(),uses:(r['u'] as num?)?.toInt()??0,fast:(r['f'] as num?)?.toDouble()??0,slow:(r['s'] as num?)?.toDouble()??0,material:(r['m'] as num?)?.toDouble()??0,cost:(r['cost'] as num?)?.toDouble()??1.1);
      m.edges[(r['k']??m._ek(e.a,e.b)).toString()]=e;
    }
    for(final r in await db.query('chunk')){
      final c=_Chunk20((r['t']??'').toString(),count:(r['c'] as num?)?.toInt()??0,material:(r['m'] as num?)?.toDouble()??0);
      m.chunks[c.text]=c;
    }
    final rows=await db.query('meta');
    final meta=<String,String>{for(final r in rows)(r['k']??'').toString():(r['v']??'').toString()};
    m.sentences=int.tryParse(meta['sentences']??'')??0;
    m.characters=int.tryParse(meta['characters']??'')??0;
    m.lastFlux=double.tryParse(meta['flux']??'')??0;
    m._rebuildIndexes21();
    return m;
  }

  Future<MgdLanguage20?> load() async {
    final db=await _db();
    final current=await _loadDb26(db);
    if(current!=null)return current;
    final legacy=await _legacyFile26();
    if(!await legacy.exists())return null;
    try{
      final raw=await legacy.readAsString();
      final map=await compute(_decodeLanguageLegacy26,raw);
      final m=MgdLanguage20.fromJson(map);
      // Migration is deliberately deferred: first usable frame does not wait
      // for tens of thousands of SQLite inserts.
      final snapshot=Map<String,dynamic>.from(m.toJson());
      _migration26=Future<void>.delayed(const Duration(milliseconds:900),()=>_writeFull26(snapshot));
      return m;
    }catch(_){
      final bak=File('${legacy.path}.bak');
      if(!await bak.exists())return null;
      final raw=await bak.readAsString();
      final map=await compute(_decodeLanguageLegacy26,raw);
      final m=MgdLanguage20.fromJson(map);
      final snapshot=Map<String,dynamic>.from(m.toJson());
      _migration26=Future<void>.delayed(const Duration(milliseconds:900),()=>_writeFull26(snapshot));
      return m;
    }
  }

  Future<void> _writeFull26(Map<String,dynamic> snapshot) async {
    final db=await _db();
    final tc=Map<String,dynamic>.from((snapshot['tc'] as Map?)??const <String,dynamic>{});
    final es=(snapshot['e'] as List?)??const [];
    final cs=(snapshot['ch'] as List?)??const [];
    await db.transaction((txn) async {
      await txn.delete('token');await txn.delete('edge');await txn.delete('chunk');await txn.delete('meta');
      var batch=txn.batch();var n=0;
      for(final e in tc.entries){batch.insert('token',{'t':e.key,'c':(e.value as num).toInt()},conflictAlgorithm:ConflictAlgorithm.replace);if(++n%700==0){await batch.commit(noResult:true);batch=txn.batch();}}
      for(final raw in es){final x=Map<String,dynamic>.from(raw as Map);final a=(x['a']??'').toString(),b=(x['b']??'').toString();batch.insert('edge',{'k':'$a\\u0001$b','a':a,'b':b,'u':x['u'],'f':x['f'],'s':x['s'],'m':x['m'],'cost':x['c']},conflictAlgorithm:ConflictAlgorithm.replace);if(++n%700==0){await batch.commit(noResult:true);batch=txn.batch();}}
      for(final raw in cs){final x=Map<String,dynamic>.from(raw as Map);final t=(x['t']??'').toString();if(t.isEmpty)continue;batch.insert('chunk',{'t':t,'h':t.split(' ').first,'c':x['c'],'m':x['m']},conflictAlgorithm:ConflictAlgorithm.replace);if(++n%700==0){await batch.commit(noResult:true);batch=txn.batch();}}
      batch.insert('meta',{'k':'initialized','v':'1'},conflictAlgorithm:ConflictAlgorithm.replace);
      batch.insert('meta',{'k':'sentences','v':'${snapshot['sentences']??0}'},conflictAlgorithm:ConflictAlgorithm.replace);
      batch.insert('meta',{'k':'characters','v':'${snapshot['characters']??0}'},conflictAlgorithm:ConflictAlgorithm.replace);
      batch.insert('meta',{'k':'flux','v':'${snapshot['flux']??0}'},conflictAlgorithm:ConflictAlgorithm.replace);
      await batch.commit(noResult:true);
    });
  }

  Future<void> save(MgdLanguage20 m) async {
    final migration=_migration26;if(migration!=null){try{await migration;}finally{_migration26=null;}}
    if(!m._hasDirty26)return;
    final delta=m._takeDelta26();
    final next=_saveTail.catchError((_){ }).then((_)=>_writeDelta26(delta));
    _saveTail=next;
    try{await next;}catch(_){m._restoreDelta26(delta);rethrow;}
  }

  Future<void> _writeDelta26(Map<String,dynamic> d) async {
    final db=await _db();
    await db.transaction((txn) async {
      final batch=txn.batch();
      for(final x in (d['tokens'] as List? ?? const[])){final r=Map<String,dynamic>.from(x as Map);batch.insert('token',{'t':r['t'],'c':r['c']},conflictAlgorithm:ConflictAlgorithm.replace);}
      for(final x in (d['edges'] as List? ?? const[])){final r=Map<String,dynamic>.from(x as Map);batch.insert('edge',{'k':r['k'],'a':r['a'],'b':r['b'],'u':r['u'],'f':r['f'],'s':r['s'],'m':r['m'],'cost':r['c']},conflictAlgorithm:ConflictAlgorithm.replace);}
      for(final x in (d['chunks'] as List? ?? const[])){final r=Map<String,dynamic>.from(x as Map);batch.insert('chunk',{'t':r['t'],'h':r['h'],'c':r['c'],'m':r['m']},conflictAlgorithm:ConflictAlgorithm.replace);}
      for(final x in (d['deletedChunks'] as List? ?? const[]))batch.delete('chunk',where:'t=?',whereArgs:[x.toString()]);
      final meta=d['meta'];if(meta is Map){
        batch.insert('meta',{'k':'initialized','v':'1'},conflictAlgorithm:ConflictAlgorithm.replace);
        for(final k in ['sentences','characters','flux'])batch.insert('meta',{'k':k,'v':'${meta[k]}'},conflictAlgorithm:ConflictAlgorithm.replace);
      }
      await batch.commit(noResult:true);
    });
  }

  Future<void> clear() async {
    final db=_db26;if(db!=null){await db.close();_db26=null;}
    final path=await _dbPath26();
    if(await databaseExists(path))await deleteDatabase(path);
    final legacy=await _legacyFile26();
    for(final f in [legacy,File('${legacy.path}.bak')])if(await f.exists())await f.delete();
  }
}

Map<String,dynamic> _decodeLanguageLegacy26(String raw)=>Map<String,dynamic>.from(jsonDecode(raw) as Map);
'''
s=s[:start]+new_persist+s[end:]
p.write_text(s)

# Add sqflite.
p=root/'pubspec.yaml'
s=p.read_text()
if 'sqflite:' not in s:
    s=s.replace('  file_picker: ^10.3.3','  file_picker: ^10.3.3\n  sqflite: ^2.4.2')
s=s.replace('version: 0.25.2+40','version: 0.26.0+41')
p.write_text(s)

# -----------------------------------------------------------------------------
# Brain load: never recompute O(N^2) concepts during deserialization.
# -----------------------------------------------------------------------------
p=root/'lib'/'plastic_language_brain_v04.dart'
s=p.read_text()
old="""    b.discoverConcepts();
    return b;
  }

  static PlasticLanguageBrain04 migrateFromV03"""
new="""    // Concepts are persisted. Re-discovering them on every startup is O(N²)
    // in entity count and caused multi-second boots after large teacher packs.
    // Learning/maintenance paths still update concepts when the graph changes.
    return b;
  }

  static PlasticLanguageBrain04 migrateFromV03"""
if old not in s: raise SystemExit('brain fromJson discover anchor missing')
s=s.replace(old,new,1)
p.write_text(s)

# -----------------------------------------------------------------------------
# Boot all independent stores concurrently and report 0.26.
# -----------------------------------------------------------------------------
p=root/'lib'/'main.dart'
s=p.read_text()
old="""      if (mounted) setState(() => _status = 'Carico memoria linguistica…');
      final loaded = await _persistence.load();
      if (mounted) setState(() => _status = 'Carico mondo sensoriale…');
      final world = await _worldPersistence.load();
      if (mounted) setState(() => _status = 'Carico ricerca e provenienza…');
      final research = await _researchPersistence.load();
      if (mounted) setState(() => _status = 'Carico geometria linguistica MGD…');
      final language = await _languagePersistence20.load();"""
new="""      if (mounted) setState(() => _status = 'Carico memorie MGD 0.26 in parallelo…');
      final loadedParts = await Future.wait<dynamic>([
        _persistence.load(),
        _worldPersistence.load(),
        _researchPersistence.load(),
        _languagePersistence20.load(),
      ]);
      final loaded = loadedParts[0] as ({PlasticLanguageBrain04 brain, bool migrated})?;
      final world = loadedParts[1] as MgdWorld06?;
      final research = loadedParts[2] as ResearchMemory11?;
      final language = loadedParts[3] as MgdLanguage20?;"""
if old not in s: raise SystemExit('boot sequential anchor missing')
s=s.replace(old,new,1)
s=s.replace("'Nuovo cervello 0.20 • avvio", "'Nuovo cervello 0.26 • avvio")
s=s.replace("'Cervello 0.20 ripristinato • avvio", "'Cervello 0.26 ripristinato • avvio")
s=s.replace('MGD Neuro 0.25.2','MGD Neuro 0.26')
s=s.replace('Memorie MGD 0.24','Memorie MGD 0.26')
p.write_text(s)

# -----------------------------------------------------------------------------
# Topology-aware adaptive graph layout + complete PNG export.
# -----------------------------------------------------------------------------
p=root/'lib'/'navigable_graph_v013.dart'
s=p.read_text()
# Replace layout method.
start=s.index('  _GraphLayout13 _layout() {')
end=s.index('\n  List<SemanticLink13> _connectionsOf',start)
layout=r'''  int _hash26(String s){
    var h=0x811c9dc5;
    for(final c in s.codeUnits){h=((h^c)*0x01000193)&0x7fffffff;}
    return h;
  }

  _GraphLayout13 _layout() {
    final links=_allLinks;
    var topology=17;
    for(final l in links){
      topology=((topology*31)^_hash26(l.from)^(_hash26(l.to)<<1)^(_hash26(l.relation)<<2)^((l.confidence*1000).round()))&0x7fffffff;
    }
    final cacheKey='${_memoryMode24}|${_focus ?? ''}|$_depth|$_nodeLimit|${_minConfidence.toStringAsFixed(3)}|${links.length}|$topology';
    if(_layoutCacheKey==cacheKey&&_layoutCache!=null)return _layoutCache!;
    if(links.isEmpty){
      const empty=_GraphLayout13(nodes:<String>[],links:<SemanticLink13>[],positions:<String,Offset>{},labelNodes:<String>{},canvasSize:Size(1800,1300));
      _layoutCache=empty;_layoutCacheKey=cacheKey;return empty;
    }

    final adjacency=<String,Map<String,double>>{};
    final degree=<String,int>{};
    for(final l in links){
      adjacency.putIfAbsent(l.from,()=> <String,double>{})[l.to]=max(adjacency[l.from]?[l.to]??0,l.confidence);
      adjacency.putIfAbsent(l.to,()=> <String,double>{})[l.from]=max(adjacency[l.to]?[l.from]??0,l.confidence);
      degree[l.from]=(degree[l.from]??0)+1;degree[l.to]=(degree[l.to]??0)+1;
    }
    for(final n in _cachedNodes){adjacency.putIfAbsent(n,()=> <String,double>{});degree.putIfAbsent(n,()=>0);}

    final targetLimit=_nodeLimit<0?_cachedNodes.length:min(_nodeLimit,_cachedNodes.length);
    final selected=<String>{};final level=<String,int>{};final focus=_focus;
    if(focus!=null&&adjacency.containsKey(focus)){
      final q=<String>[focus];level[focus]=0;selected.add(focus);var head=0;
      while(head<q.length&&selected.length<targetLimit){
        final cur=q[head++],d=level[cur]??0;if(d>=_depth)continue;
        final ns=(adjacency[cur]?.keys.toList()??<String>[])..sort((a,b)=>(degree[b]??0).compareTo(degree[a]??0));
        for(final n in ns){if(selected.length>=targetLimit)break;if(selected.add(n)){level[n]=d+1;q.add(n);}}
      }
    }else{
      final ranked=degree.entries.toList()..sort((a,b)=>b.value.compareTo(a.value));
      for(final e in ranked.take(targetLimit))selected.add(e.key);
    }
    final visibleLinks=links.where((l)=>selected.contains(l.from)&&selected.contains(l.to)).toList(growable:false);
    final n=selected.length;
    if(n==0){const empty=_GraphLayout13(nodes:<String>[],links:<SemanticLink13>[],positions:<String,Offset>{},labelNodes:<String>{},canvasSize:Size(1800,1300));return empty;}

    final positions=<String,Offset>{};
    if(focus!=null&&selected.contains(focus)){
      // Focus mode: causal neighbourhood rings are more readable than a global force map.
      final side=max(1800.0,650.0+320.0*_depth);final canvas=Size(side,side*.82);final center=Offset(canvas.width/2,canvas.height/2);
      positions[focus]=center;
      final levels=<int,List<String>>{};
      for(final node in selected){if(node==focus)continue;levels.putIfAbsent(level[node]??_depth,()=> <String>[]).add(node);}
      final maxR=min(canvas.width,canvas.height)*.42;
      for(final e in levels.entries){
        final xs=e.value..sort((a,b)=>(degree[b]??0).compareTo(degree[a]??0));final r=maxR*e.key/max(1,_depth);
        for(var i=0;i<xs.length;i++){final a=2*pi*i/max(1,xs.length)-pi/2;positions[xs[i]]=center+Offset(cos(a)*r,sin(a)*r);}
      }
      final labels=_labels26(selected,degree,focus);
      final out=_GraphLayout13(nodes:selected.toList(growable:false),links:visibleLinks,positions:positions,labelNodes:labels,canvasSize:canvas);
      _layoutCache=out;_layoutCacheKey=cacheKey;return out;
    }

    // Global mode: weighted label-propagation communities + a light
    // ForceAtlas/LinLog-style relaxation. Unlike the old golden spiral, the
    // geometry now depends on the actual graph topology and edge confidence.
    final labels=<String,String>{for(final x in selected)x:x};
    final sizes=<String,int>{for(final x in selected)x:1};
    final order=selected.toList()..sort((a,b)=>(degree[b]??0).compareTo(degree[a]??0));
    const maxCommunity=140;
    for(var iter=0;iter<7;iter++){
      var changed=0;
      for(final x in order){
        final scores=<String,double>{};
        for(final e in (adjacency[x]??const <String,double>{}).entries){
          if(!selected.contains(e.key))continue;final lab=labels[e.key]!;scores[lab]=(scores[lab]??0)+.25+e.value;
        }
        if(scores.isEmpty)continue;
        final current=labels[x]!;
        final ranked=scores.entries.toList()..sort((a,b){final c=b.value.compareTo(a.value);return c!=0?c:a.key.compareTo(b.key);});
        final best=ranked.first.key;
        if(best!=current&&(sizes[best]??0)<maxCommunity){sizes[current]=max(0,(sizes[current]??1)-1);sizes[best]=(sizes[best]??0)+1;labels[x]=best;changed++;}
      }
      if(changed==0)break;
    }
    final groups=<String,List<String>>{};for(final x in selected)groups.putIfAbsent(labels[x]!,()=> <String>[]).add(x);
    final communities=groups.values.toList()..sort((a,b)=>b.length.compareTo(a.length));

    const golden=2.399963229728653;
    final baseSide=n<=300?1900.0:n<=1200?3400.0:n<=4000?5600.0:min(12000.0,5600+sqrt(n-4000)*70);
    final provisionalCenter=Offset(baseSide/2,baseSide*.41);
    final centers=<String,Offset>{};
    for(var ci=0;ci<communities.length;ci++){
      final g=communities[ci];final key=labels[g.first]!;
      final rr=(70+sqrt(ci+1)*165+sqrt(g.length)*18).clamp(80.0,baseSide*.38).toDouble();
      final aa=ci*golden+(_hash26(key)%1000)/1000.0*.45;
      centers[key]=provisionalCenter+Offset(cos(aa)*rr,sin(aa)*rr*.78);
      final hub=(g.toList()..sort((a,b)=>(degree[b]??0).compareTo(degree[a]??0))).first;
      final localLevel=<String,int>{hub:0};final q=<String>[hub];var h=0;
      while(h<q.length){final cur=q[h++],d=localLevel[cur]!;for(final y in (adjacency[cur]?.keys??const <String>{})){if(!g.contains(y)||localLevel.containsKey(y))continue;localLevel[y]=d+1;q.add(y);}}
      final rings=<int,List<String>>{};for(final x in g)if(x!=hub)rings.putIfAbsent(localLevel[x]??3,()=> <String>[]).add(x);
      positions[hub]=centers[key]!;
      for(final e in rings.entries){
        final xs=e.value..sort((a,b)=>_hash26(a).compareTo(_hash26(b)));final r=52.0+e.key*(45.0+sqrt(g.length)*5.0);
        for(var i=0;i<xs.length;i++){final aa=2*pi*i/max(1,xs.length)+(_hash26(hub)%628)/100.0;positions[xs[i]]=centers[key]!+Offset(cos(aa)*r,sin(aa)*r);}
      }
    }

    // Sparse force relaxation. Attraction follows actual edges; a spatial grid
    // prevents node collapse without O(N²) repulsion.
    for(var iter=0;iter<18;iter++){
      final delta=<String,Offset>{for(final x in selected)x:Offset.zero};
      for(final l in visibleLinks){
        final a=positions[l.from]!,b=positions[l.to]!;final v=b-a;final dist=max(1.0,v.distance);final unit=v/dist;
        final desired=82.0+95.0*(1-l.confidence.clamp(0.0,1.0));final f=((dist-desired)*.045*l.confidence).clamp(-18.0,18.0).toDouble();
        delta[l.from]=delta[l.from]!+unit*f;delta[l.to]=delta[l.to]!-unit*f;
      }
      final cell=<String,List<String>>{};const cellSize=72.0;
      for(final x in selected){final p=positions[x]!;final k='${(p.dx/cellSize).floor()}:${(p.dy/cellSize).floor()}';cell.putIfAbsent(k,()=> <String>[]).add(x);}
      for(final x in selected){
        final p=positions[x]!;final gx=(p.dx/cellSize).floor(),gy=(p.dy/cellSize).floor();
        for(var dx=-1;dx<=1;dx++)for(var dy=-1;dy<=1;dy++)for(final y in cell['${gx+dx}:${gy+dy}']??const <String>[]){
          if(x.compareTo(y)>=0)continue;final q=positions[y]!;var v=q-p;var d=v.distance;if(d<1){final a=(_hash26(x)^_hash26(y))%628/100.0;v=Offset(cos(a),sin(a));d=1;}
          if(d<42){final u=v/d,f=(42-d)*.16;delta[x]=delta[x]!-u*f;delta[y]=delta[y]!+u*f;}
        }
        final c=centers[labels[x]!]!;delta[x]=delta[x]!+(c-p)*.006;
      }
      final cooling=1.0-iter/24.0;
      for(final x in selected){final d=delta[x]!;final mag=d.distance;positions[x]=positions[x]!+(mag>24?d/mag*24:d)*cooling;}
    }

    var minX=double.infinity,minY=double.infinity,maxX=-double.infinity,maxY=-double.infinity;
    for(final p in positions.values){minX=min(minX,p.dx);minY=min(minY,p.dy);maxX=max(maxX,p.dx);maxY=max(maxY,p.dy);}
    const margin=170.0;final shift=Offset(margin-minX,margin-minY);for(final x in positions.keys.toList())positions[x]=positions[x]!+shift;
    final canvas=Size(max(1800.0,maxX-minX+margin*2),max(1300.0,maxY-minY+margin*2));
    final out=_GraphLayout13(nodes:selected.toList(growable:false),links:visibleLinks,positions:positions,labelNodes:_labels26(selected,degree,null),canvasSize:canvas);
    _layoutCache=out;_layoutCacheKey=cacheKey;return out;
  }

  Set<String> _labels26(Set<String> selected,Map<String,int> degree,String? focus){
    final ranked=selected.toList()..sort((a,b)=>(degree[b]??0).compareTo(degree[a]??0));final n=selected.length;
    final budget=n<=300?n:n<=1000?140:n<=3000?90:60;final out=ranked.take(budget).toSet();if(focus!=null)out.add(focus);return out;
  }
'''
s=s[:start]+layout+s[end:]
# Add full PNG function after _savePng25.
anchor='''  Future<void> _savePng25() async{\n'''
idx=s.index(anchor)
end_method=s.index('\n  @override\n  Widget build',idx)
existing=s[idx:end_method]
full=r'''
  Future<void> _saveFullPng26() async{
    try{
      final layout=_layout();
      if(layout.nodes.isEmpty)throw StateError('Mappa vuota');
      const maxSide=8192.0;
      final scale=min(1.0,maxSide/max(layout.canvasSize.width,layout.canvasSize.height));
      final outSize=Size(max(1,layout.canvasSize.width*scale),max(1,layout.canvasSize.height*scale));
      final recorder=ui.PictureRecorder();final canvas=Canvas(recorder);
      canvas.drawRect(Offset.zero & outSize,Paint()..color=Colors.black);
      canvas.scale(scale);
      _NavigableGraphPainter13(layout:layout,focus:_focus,showRelations:_showRelations,showNodeLabels:_showNodeLabels).paint(canvas,layout.canvasSize);
      final picture=recorder.endRecording();final image=await picture.toImage(outSize.width.ceil(),outSize.height.ceil());picture.dispose();
      final data=await image.toByteData(format:ui.ImageByteFormat.png);image.dispose();if(data==null)throw StateError('PNG non disponibile');
      final bytes=Uint8List.view(data.buffer,data.offsetInBytes,data.lengthInBytes);final stamp=DateTime.now().millisecondsSinceEpoch;
      await FilePicker.platform.saveFile(dialogTitle:'Salva mappa MGD completa',fileName:'MGD-mappa-completa-${_memoryMode24}-$stamp.png',bytes:bytes);
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Mappa completa PNG salvata.')));
    }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Errore PNG completo: $e')));}
  }
'''
s=s[:end_method]+full+s[end_method:]
# Replace button with popup.
old="""                      IconButton.filledTonal(tooltip:'Salva PNG',onPressed:_savePng25,icon:const Icon(Icons.image_outlined)),"""
new="""                      PopupMenuButton<String>(
                        tooltip:'Esporta PNG',
                        icon:const Icon(Icons.image_outlined),
                        onSelected:(v){if(v=='vista')_savePng25();else if(v=='completa')_saveFullPng26();},
                        itemBuilder:(_)=>const [
                          PopupMenuItem(value:'vista',child:Text('Salva vista PNG')),
                          PopupMenuItem(value:'completa',child:Text('Salva mappa completa PNG')),
                        ],
                      ),"""
if old not in s: raise SystemExit('png button anchor missing')
s=s.replace(old,new,1)
# Update help text.
s=s.replace('Tocca un nodo per entrarci. Usa + e − per lo zoom, Adatta per rientrare nella vista. Puoi scegliere anche Tutti: i nodi vengono disegnati tutti, mentre nomi e relazioni usano un livello di dettaglio adattivo per non bloccare il telefono.',
'''Tocca un nodo per entrarci. La geometria globale ora dipende dai collegamenti reali: comunità con molti archi stanno vicine, nodi debolmente connessi si separano. Usa + e − per lo zoom; dal pulsante immagine puoi salvare la vista o l’intera mappa PNG.''',1)
p.write_text(s)

print('patch_v026 applied')
